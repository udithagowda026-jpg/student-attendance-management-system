import tkinter as tk
from tkinter import messagebox
from datetime import date

# Save attendance
def mark_attendance(status):
    name = entry.get()
    if name == "":
        messagebox.showwarning("Warning", "Enter student name")
        return

    today = date.today()
    record = f"{name} - {status} - {today}"

    listbox.insert(tk.END, record)

    with open("attendance.txt", "a") as file:
        file.write(record + "\n")

    entry.delete(0, tk.END)

# Load attendance from file
def load_attendance():
    try:
        with open("attendance.txt", "r") as file:
            for line in file:
                listbox.insert(tk.END, line.strip())
    except FileNotFoundError:
        pass

# Main window
root = tk.Tk()
root.title("Student Attendance Tracker")
root.geometry("400x450")

# Widgets
tk.Label(root, text="Student Name", font=("Arial", 12)).pack(pady=5)

entry = tk.Entry(root, width=30)
entry.pack(pady=5)

present_btn = tk.Button(root, text="Mark Present", width=20,
                        command=lambda: mark_attendance("Present"))
present_btn.pack(pady=5)

absent_btn = tk.Button(root, text="Mark Absent", width=20,
                       command=lambda: mark_attendance("Absent"))
absent_btn.pack(pady=5)

listbox = tk.Listbox(root, width=45, height=12)
listbox.pack(pady=10)

load_attendance()

root.mainloop()